﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using UnityEngine;

namespace PrefabAPI
{
    public static class PrefabBuilder
    {
        public static void Init()
        {
            if (m_initialized)
            {
                return;
            }
            m_assetBundles = new List<AssetBundle>();
            m_initialized = true;
            builtObjects = new List<GameObject>();
        }

        public static GameObject BuildObject(string name)
        {
            if(m_assetBundles == null || builtObjects == null)
            {
                Init();
            }
            byte[] bundleBytes = AssetBundleBuilder.BuildBundleFile("runtimebundle" + m_bundlesBuilt);
            m_bundlesBuilt++;
            AssetBundle bundle = AssetBundle.LoadFromMemory(bundleBytes);
            ETGModConsole.Log("bundle != null " + (bundle != null));
            m_assetBundles.Add(bundle);
            ETGModConsole.Log("m_assetBundles != null " + (m_assetBundles != null));
            GameObject prefab = bundle.LoadAsset<GameObject>("object");
            ETGModConsole.Log("prefab != null " + (prefab != null));
            prefab.name = name;
            builtObjects.Add(prefab);
            ETGModConsole.Log("builtObjects != null " + (builtObjects != null));
            return prefab;
        }

        private static bool m_initialized;
        private static int m_bundlesBuilt;
        private static List<AssetBundle> m_assetBundles;
        public static List<GameObject> builtObjects;
    }
}
