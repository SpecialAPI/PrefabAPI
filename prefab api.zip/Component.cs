﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace PrefabAPI
{
    public abstract class Component : EditorExtension
    {
        public PPtr<EditorGameObject> m_GameObject;

        public Component()
        {
        }

        public override void Write(BinaryWriter write)
        {
            base.Write(write);
            m_GameObject.Write(write);
        }
    }
}
